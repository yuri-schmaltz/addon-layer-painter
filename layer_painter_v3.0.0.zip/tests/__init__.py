"""Layer Painter Test Suite

Tests for Layer Painter Blender add-on to ensure reliability and prevent regressions.
"""
