import bpy

from ..operators import utils_operator
from .. import utils
from ..data import utils_nodes
from ..data.materials.layers.layer_types import layer_fill
from . import utils_dialogs


class LP_OT_AddFillLayer(bpy.types.Operator):
    bl_idname = "lp.add_fill_layer"
    bl_label = "Add Fill Layer"
    bl_description = "Adds a fill layer to the active material"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    
    material: bpy.props.StringProperty(name="Material",
                                    description="Name of the material to use",
                                    options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return utils_operator.base_poll(context)

    def execute(self, context):
        mat = bpy.data.materials.get(self.material)
        if not mat:
            self.report({'ERROR'}, f"Material '{self.material}' not found. It may have been deleted.")
            return {"CANCELLED"}
        
        try:
            mat.lp.add_fill_layer()
            
            # NOTE (Joshua) currenly only used for debugging
            ntree = mat.lp.selected.node.node_tree
            utils_nodes.organize_tree(ntree, ntree.nodes["OUTPUTS"])

            utils.redraw()
            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to add fill layer: {str(e)}")
            return {"CANCELLED"}


class LP_OT_AddPaintLayer(bpy.types.Operator):
    bl_idname = "lp.add_paint_layer"
    bl_label = "Add Paint Layer"
    bl_description = "Adds a paint layer to the active material"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    
    material: bpy.props.StringProperty(name="Material",
                                    description="Name of the material to use",
                                    options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return utils_operator.base_poll(context)

    def execute(self, context):
        mat = bpy.data.materials.get(self.material)
        if not mat:
            self.report({'ERROR'}, f"Material '{self.material}' not found.")
            return {"CANCELLED"}
        
        try:
            mat.lp.add_paint_layer()
            utils.redraw()
            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to add paint layer: {str(e)}")
            return {"CANCELLED"}


class LP_OT_RemoveLayer(bpy.types.Operator):
    bl_idname = "lp.remove_layer"
    bl_label = "Remove Layer"
    bl_description = "Removes the selected layer from the active material"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    
    material: bpy.props.StringProperty(name="Material",
                                    description="Name of the material to use",
                                    options={"HIDDEN", "SKIP_SAVE"})
    
    overwrite_uid: bpy.props.StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    confirmed: bpy.props.BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        mat = utils.active_material(context)
        return utils_operator.base_poll(context) and mat.lp.selected

    def execute(self, context):
        mat = bpy.data.materials.get(self.material)
        if not mat:
            self.report({'ERROR'}, f"Material '{self.material}' not found.")
            return {"CANCELLED"}
        
        # Show confirmation dialog if not yet confirmed
        if not self.confirmed:
            if self.overwrite_uid:
                mat.lp.selected_index = mat.lp.layer_uid_index(self.overwrite_uid)
            
            # Invoke confirmation dialog
            return context.window_manager.invoke_props_dialog(self, width=300)
        
        try:
            if self.overwrite_uid:
                mat.lp.selected_index = mat.lp.layer_uid_index(self.overwrite_uid)
                
            mat.lp.remove_active_layer()
            utils.redraw()
            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to remove layer: {str(e)}")
            return {"CANCELLED"}
    
    def draw(self, context):
        """Draw confirmation dialog."""
        layout = self.layout
        mat = bpy.data.materials.get(self.material)
        
        if mat and mat.lp.selected:
            layer_name = mat.lp.selected.name
            layout.label(text=f'Delete layer "{layer_name}"?', icon="ERROR")
            layout.label(text="This action cannot be undone.", icon="BLANK1")


class LP_OT_MoveLayerUp(bpy.types.Operator):
    bl_idname = "lp.move_layer_up"
    bl_label = "Move Layer Up"
    bl_description = "Moves this layer up"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    
    material: bpy.props.StringProperty(name="Material",
                                    description="Name of the material to use",
                                    options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        mat = utils.active_material(context)
        return utils_operator.base_poll(context) and mat.lp.selected_index < len(mat.lp.layers)-1

    def execute(self, context):
        mat = bpy.data.materials.get(self.material)
        if not mat:
            self.report({'ERROR'}, f"Material '{self.material}' not found.")
            return {"CANCELLED"}
        
        try:
            mat.lp.move_active_layer_up()
            utils.redraw()
            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to move layer: {str(e)}")
            return {"CANCELLED"}


class LP_OT_MoveLayerDown(bpy.types.Operator):
    bl_idname = "lp.move_layer_down"
    bl_label = "Move Layer Down"
    bl_description = "Moves this layer down"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    
    material: bpy.props.StringProperty(name="Material",
                                    description="Name of the material to use",
                                    options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        mat = utils.active_material(context)
        return utils_operator.base_poll(context) and mat.lp.selected_index > 0

    def execute(self, context):
        mat = bpy.data.materials.get(self.material)
        if not mat:
            self.report({'ERROR'}, f"Material '{self.material}' not found.")
            return {"CANCELLED"}
        
        try:
            mat.lp.move_active_layer_down()
            utils.redraw()
            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to move layer: {str(e)}")
            return {"CANCELLED"}


class LP_OT_CycleChannelData(bpy.types.Operator):
    bl_idname = "lp.cycle_channel_data"
    bl_label = "Cycle Channel Data"
    bl_description = "Cycles this channels data type to the next"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    
    material: bpy.props.StringProperty(name="Material",
                                    description="Name of the material to use",
                                    options={"HIDDEN", "SKIP_SAVE"})
    
    layer_uid: bpy.props.StringProperty(options={"HIDDEN", "SKIP_SAVE"})

    channel_uid: bpy.props.StringProperty(options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return utils_operator.base_poll(context)

    def execute(self, context):
        mat = bpy.data.materials.get(self.material)
        if not mat:
            self.report({'ERROR'}, f"Material '{self.material}' not found.")
            return {"CANCELLED"}
        
        try:
            layer = mat.lp.layer_by_uid(self.layer_uid)
            if not layer:
                self.report({'ERROR'}, f"Layer not found. It may have been deleted.")
                return {"CANCELLED"}

            layer_fill.cycle_channel_data_type(layer, self.channel_uid)
            utils.redraw()
            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to cycle channel data: {str(e)}")
            return {"CANCELLED"}
